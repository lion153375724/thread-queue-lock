package cn.byhieg.threadtutorial.concurrent.atom;

/**
 * Created by shiqifeng on 2017/5/5.
 * Mail byhieg@gmail.com
 */
public class MyObject {

    public String name = "byhieg";
    public int age = 24;
    public volatile int id = 1;
}
