package cn.byhieg.designpatterntutorial.singleton;

/**
 * Created by shiqifeng on 2017/3/14.
 * Mail byhieg@gmail.com
 */
public enum EnumSingleton {
    SINGLETON;


    public void doSometings(){

    }
}
