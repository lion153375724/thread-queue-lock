package cn.byhieg.collectiontutorial.listtutorial;

import java.util.LinkedList;

/**
 * Created by byhieg on 17/2/15.
 * Mail to byhieg@gmail.com
 */
public class LinkedListDemo {

    private LinkedList list = new LinkedList();

    public LinkedList getList() {
        return list;
    }

    public void setList(LinkedList list) {
        this.list = list;
    }
}
