package cn.byhieg.threadtutorial.char05.one2one.value;

/**
 * Created by byhieg on 17/2/1.
 * Mail to byhieg@gmail.com
 */
public class ValueObject {
    public static String value = "";
}
