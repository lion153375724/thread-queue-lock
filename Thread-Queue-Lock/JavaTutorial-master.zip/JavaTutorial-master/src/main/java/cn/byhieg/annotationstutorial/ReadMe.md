# Java 注解

Java注解是Java1.5以后提供用来标注类，变量，方法等，其目的在于给这些类，变量，方法提供形式化的信息。
注解的写法和用法都是大同小异，一个格式，因此这篇注解的主要内容，是提供一些比较好的注解方面的文章。

在[源码](https://github.com/byhieg/JavaTutorial/tree/master/src/main/java/cn/byhieg/annotationstutorial)中提供了构造器和方法的运行时注解和一个APT编译前注解的例子。

注解相关的文章：

- [注解的讲解](http://blog.csdn.net/dd864140130/article/details/53875814)
- [APT的讲解](https://github.com/OriginalLove/JavaAdvanced/blob/master/Java%E6%B3%A8%E8%A7%A3%E4%BA%8C.md)



