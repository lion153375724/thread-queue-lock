package cn.byhieg.reflectiontutorial;

import java.util.List;

/**
 * Created by byhieg on 17/1/9.
 * Mail to byhieg@gmail.com
 */
public class GenericObject {
    public List<String> lists;

    public List<String> getLists() {
        return lists;
    }

    public void setLists(List<String> lists) {
        this.lists = lists;
    }
}
