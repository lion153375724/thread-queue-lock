package cn.byhieg.designpatterntutorial.proxy.dynamicproxy;

/**
 * Created by shiqifeng on 2017/3/17.
 * Mail byhieg@gmail.com
 */
public interface Subject {

    void visit();
}
