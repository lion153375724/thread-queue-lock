package cn.byhieg.threadtutorial.char01;

/**
 * Created by shiqifeng on 2016/12/27.
 * Mail byhieg@gmail.com
 */
public class ExampleRunable  implements Runnable{

    public void run() {
        System.out.println("这是实现Runnable接口的类");
    }
}
